# DOMAIN MANAGER — BUILD STATE

## Identidade

- Module version: `0.0.2`
- Gate de código atual: `G2 — G2.2 Transport adapter + authenticated sender`
- Estado local: `G2_2A_COMMAND_TRANSPORT_AUTHENTICATED_SENDER_VALIDATED`
- Estado externo: `READY_FOR_EXTERNAL_FOUNDRY_SMOKE`
- Schema Domain: `1`
- Data da auditoria: `2026-09-17`

## Estado canônico

G0 e G1 possuem implementação local. O smoke real de instalação/boot no Foundry VTT v13.351+ ainda não foi fornecido pelo usuário e continua sendo uma condição externa pendente. Portanto este arquivo não declara falsamente `GATE_ACCEPTED` do encadeamento completo.

## G1 implementado

- schema/validators canônicos de Domain;
- JournalEntry name como única verdade do nome;
- codec em `flags.domain-manager`;
- production boundary `FoundryDomainDocumentStore` para `game.journal`/`JournalEntry.create`;
- DomainRepository create/read/query/save/update/archive/restore/reparent;
- revision otimista e no-op;
- hierarchy por UUID Foundry completo e cycle prevention;
- capability shell/effective resolution;
- índice rebuildable + incremental, incluindo UUID;
- integrity checker read-only;
- migration seed v1;
- runtime package + full checkpoint scripts.

## Correções da auditoria de G1

1. parent refs migrados de local ID para full Foundry UUID;
2. save/update agora não conseguem burlar cycle/reparent validation;
3. query usa índice após lazy rebuild inicial;
4. deep validator não lança por payload malformado;
5. canonicalização de aliases/tags/technical IDs aplicada na persistence boundary;
6. índice passa a armazenar UUID canonical;
7. production Foundry store criado;
8. ordinary JournalEntries sem Domain flag são ignorados;
9. closeout documental consolidado;
10. full-checkpoint validator fortalecido.

Detalhes completos: `docs/G1_AUDIT_FIX_REPORT.md`.

## Evidência local

| Verificação | Resultado |
|---|---|
| TypeScript strict (`npm run typecheck`) | PASS |
| Testes de auditoria | PASS — 68/68 |
| Manifest/package validation | PASS |
| Runtime ZIP generation | PASS |
| Runtime artifact validation | PASS |
| Full Gate 1 checkpoint validation | PASS |
| `node --check dist/main.js` | PASS |

O runner nativo do projeto e o rebuild esbuild não puderam ser repetidos neste container porque o ZIP não traz `node_modules` e o registry não ficou acessível. A suíte foi executada com transpile TypeScript + `node --test`; nenhum resultado nativo foi inventado.

## Pendência externa

1. instalar o runtime ZIP no Foundry VTT v13.351+;
2. ativar em world vazio;
3. confirmar logs `init` e `ready`;
4. confirmar ausência de erro crítico no console;
5. registrar a evidência de smoke.

## Microtarefa de fundação G2 concluída

- composition root criado em `src/bootstrap/domain-manager-runtime.ts`;
- `src/main.ts` compõe os serviços G1 apenas em `ready`;
- nenhum write ocorre durante composição;
- nenhum transport, CommandBus, mutation ou Authority foi antecipado;
- suíte ampliada: 71/71 PASS;
- `tsc --noEmit`: PASS;
- `dist/main.js` permanece o bundle anterior porque o build oficial esbuild não está disponível neste ambiente.

Relatório: `docs/G2_MT00_COMPOSITION_ROOT_REPORT.md`.

## Próxima ação

Implementar `G2.1 — Primary Authority election/status` em microtarefas pequenas, mantendo transport/socket, CommandBus, dedupe e locks fora do escopo até seus microbuilds donos.

## G2.1a — Deterministic Primary Authority election core

Status: `VALIDATED_SOURCE`

Implementado:
- `src/authority/primary-authority-election.ts` define a projeção mínima de usuário usada pela eleição;
- preferred GM ativo vence;
- preferred offline/não-GM cai para fallback;
- fallback considera apenas GMs ativos e ordena explicitamente por `userId`;
- ordem incidental de collection não influencia o resultado;
- ausência de GM elegível retorna `null`;
- IDs vazios são ignorados defensivamente;
- eleição retorna somente `userId`, não objeto de collection, para evitar dependência de identidade/ordem de instância.

Evidência:
- `npm run typecheck`: PASS;
- suíte completa via transpile TypeScript + `node --test`: PASS — 80/80;
- testes novos da eleição: 9/9 PASS;
- `npm run validate:package`: PASS;
- `npm run test:unit`: não executável neste ambiente por ausência local de `esbuild`; nenhum resultado nativo foi inventado.

Não implementado nesta microtarefa:
- persistence de preferred GM;
- authority epoch;
- callbacks/status stateful;
- Foundry settings/users adapter;
- lifecycle `ready`/conexão/desconexão;
- transport/socket, CommandBus, dedupe, locks ou mutations.

Relatório: `docs/G2_MT01_AUTHORITY_ELECTION_REPORT.md`.

## Próxima ação G2

Implementar `G2.1b — Authority epoch + stateful status service`, consumindo a eleição pura desta microtarefa. A próxima parte não deve ainda importar socketlib, CommandBus ou MutationCoordinator.


## G2.1b — Authority epoch + stateful status service

Status: `VALIDATED_SOURCE`

Implementado:
- `src/authority/primary-authority-service.ts` mantém o estado efetivo da Primary Authority sem importar Foundry APIs;
- `getCurrent()`, `isCurrentUser()`, `resolve()` e `onChanged()` seguem o contrato conceitual do Master;
- `getStatus()` expõe `authorityUserId`, `authorityEpoch` e disponibilidade para diagnostics internos;
- o primeiro resolve de uma instância não inicializada estabelece baseline sem fabricar um epoch novo;
- mudanças efetivas posteriores incrementam o epoch exatamente uma vez;
- reordenação da collection, preferred inválido e outros inputs sem mudança efetiva não geram churn;
- refinado em G2.1c: ausência temporária de GM não inventa novo executor/epoch; somente troca real entre executores incrementa o epoch;
- estado inicial pode ser reidratado por adapter futuro;
- overflow de epoch falha de forma atômica antes de alterar authority;
- callbacks podem ser removidos por unsubscribe idempotente.

Evidência:
- `npm run typecheck`: PASS;
- suíte completa via transpile TypeScript + `node --test`: PASS — 94/94;
- testes novos do stateful service: 14/14 PASS;
- `npm run validate:package`: PASS;
- `npm run test:unit`: ainda não executável neste ambiente por ausência local de `esbuild`; nenhum resultado nativo foi inventado.

Não implementado nesta microtarefa:
- world settings para preferred GM/epoch;
- adapter de `game.users`/`game.user`;
- listeners de conexão/desconexão e lifecycle Foundry;
- socket/transport;
- CommandBus, dedupe, locks, mutations ou recovery.

Relatório: `docs/G2_MT02_AUTHORITY_STATE_REPORT.md`.

## Próxima ação G2

G2.1c concluída e validada. Próxima ação: iniciar `G2.2a — CommandTransport contract + authenticated sender boundary`, sem socketlib concreto ainda.


## G2.1c — Foundry authority adapter + lifecycle + lightweight persistence

Status: `VALIDATED_SOURCE`

Implementado:
- `src/authority/foundry-primary-authority-adapter.ts` liga o core de Authority a `game.users`, `game.user` e `game.settings` por boundary injetável/testável;
- preferred GM vive em world setting oculto `preferredAuthorityUserId`;
- estado técnico `{authorityUserId, authorityEpoch, initialized}` é persistido atomicamente em um único world setting JSON `primaryAuthorityState`;
- settings são registrados em `init`;
- runtime/authority são compostos e resolvidos em `ready`;
- `userConnected` dispara reconciliação de conexão/desconexão;
- apenas o cliente da authority recém-eleita persiste mudanças de state, evitando corrida de writes entre clientes;
- state sync remoto é monotônico e rejeita conflito de identidade no mesmo epoch;
- ausência temporária de GMs retém a última identidade técnica e não cria epoch impossível de persistir;
- retorno do mesmo GM preserva epoch; troca para outro GM incrementa exatamente uma vez;
- `DomainManagerRuntime` agora possui boundary explícita `authority` sem introduzir CommandBus/socket/mutation.

Correção arquitetural descoberta nesta microtarefa:
- a semântica anterior de G2.1b incrementava epoch ao entrar/sair de um período sem GM. Isso podia gerar drift local em players porque nenhum GM estava presente para persistir o epoch intermediário. G2.1c corrige o modelo: `authorityUserId` guarda o último executor eleito enquanto indisponível; `available` deriva do snapshot atual de users; epoch só avança quando o executor real muda.

Evidência:
- `npm run typecheck`: PASS;
- testes Authority direcionados via transpile TypeScript + `node --test`: PASS — 37/37;
- suíte completa via transpile TypeScript + `node --test`: PASS — 108/108;
- `npm run validate:package`: PASS;
- `npm run test:unit`: não executável neste ambiente por ausência local de `esbuild`; nenhum resultado nativo foi inventado.

Não implementado nesta microtarefa:
- CommandTransport/socket/socketlib;
- AuthenticatedCommandContext;
- CommandBus/registry;
- dedupe/rate limit;
- locks;
- MutationCoordinator/Plan/Receipt/recovery.

Relatório: `docs/G2_MT03_FOUNDRY_AUTHORITY_ADAPTER_REPORT.md`.

## Próxima ação G2

G2.1c concluída e validada. Próxima ação: iniciar `G2.2a — CommandTransport contract + authenticated sender boundary`, sem socketlib concreto ainda.


## G2.2a — CommandTransport contract + Authenticated Sender Boundary

Status: `VALIDATED_SOURCE`

Implementado:
- `src/commands/command-envelope.ts` define o contrato puro de `DomainCommand`, `CommandId` branded (`cmd_${string}`), validação de envelope fail-closed (`validateCommandEnvelope`), integridade recursiva JSON-safe e estrutura declarativa de `expectedRevision`/`expectedRevisions`;
- `src/commands/command-transport.ts` define a abstração pura `CommandTransport`, `TransportReceipt` com status (`delivered`, `acknowledged`, `executed`, `rejected`, `timed_out`), `TransportInboundContext` e handlers de recebimento;
- `src/commands/authenticated-command-context.ts` define `AuthenticatedCommandContext` e a fábrica de fronteira de segurança `createAuthenticatedCommandContext`;
- `senderUserId` é extraído exclusivamente do transporte e nunca do payload;
- Testes adversariais provam que tentativas de spoofing no payload (`userId`, `claimedUserId`, `senderUserId`, `senderId`, `user.id`) são detectadas e rejeitadas como `DM_SECURITY_SENDER_SPOOFED`;
- Comandos técnicos da autoridade local funcionam com remetente nulo e `OperationSource` apropriado (`tick`, etc.);
- Todos os contratos são estritamente isolados de APIs do Foundry VTT e bibliotecas de socket (socketlib).

Evidência:
- `npm run typecheck`: PASS;
- `npm run test:unit`: PASS — 132/132 (24 novos testes direcionados e adversariais para G2.2a);
- `npm run validate:package`: PASS;
- `npm run build`: PASS;
- `node --check dist/main.js`: PASS;
- `npm run package` e `npm run validate:artifact`: PASS.

Não implementado nesta microtarefa:
- Escolha definitiva de socketlib vs native socket;
- Implementação de adapter concreto de transporte Foundry;
- CommandBus e command registry;
- Dedupe store e rate limiter;
- LockManager e MutationCoordinator;
- TransactionStore e recovery.

Relatório: `docs/G2_MT04_COMMAND_TRANSPORT_AUTHENTICATED_SENDER_REPORT.md`.

## Próxima ação G2

Implementar `G2.2b — Transport adapter / socket boundary abstraction` conforme a decomposição planejada do Gate G2.

