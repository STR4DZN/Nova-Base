import assert from "node:assert/strict";
import test from "node:test";
import { sanitizeDiagnosticsValue } from "../../src/diagnostics/sanitize.js";

test("sanitizer redacts sensitive nested fields", () => {
  const result = sanitizeDiagnosticsValue({
    moduleVersion: "0.0.1",
    credentials: {
      apiKey: "hidden",
      nested: [{ token: "hidden" }]
    },
    safe: "visible"
  });

  assert.deepEqual(result, {
    moduleVersion: "0.0.1",
    credentials: "[REDACTED]",
    safe: "visible"
  });
});

test("sanitizer preserves primitive values and arrays", () => {
  assert.equal(sanitizeDiagnosticsValue("safe"), "safe");
  assert.deepEqual(sanitizeDiagnosticsValue(["safe", { password: "hidden" }]), [
    "safe",
    { password: "[REDACTED]" }
]);
});

test("sanitizer represents circular references safely", () => {
  const value: { name: string; self?: unknown } = { name: "cycle" };
  value.self = value;
  assert.deepEqual(sanitizeDiagnosticsValue(value), {
    name: "cycle",
    self: "[Circular]"
  });
});
