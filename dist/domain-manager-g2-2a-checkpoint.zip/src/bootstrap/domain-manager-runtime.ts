import {
  FoundryPrimaryAuthorityAdapter,
  type PrimaryAuthorityHost
} from "../authority/foundry-primary-authority-adapter.js";
import { FoundryDomainDocumentStore } from "../storage/adapters/foundry-domain-document-store.js";
import {
  DomainRepository,
  type DomainDocumentStore,
  type DomainRepositoryContract
} from "../storage/repositories/domain-repository.js";

/**
 * Runtime services owned by the Domain Manager composition root.
 *
 * This object is intentionally small. Subsystems receive their dependencies
 * from composition instead of reaching into Foundry globals or constructing
 * repositories ad hoc.
 */
export interface DomainManagerRuntime {
  readonly domains: DomainRepositoryContract;
  readonly authority: PrimaryAuthorityHost;
}

export interface DomainManagerRuntimeOptions {
  readonly domainStore?: DomainDocumentStore;
  readonly authority?: PrimaryAuthorityHost;
}

/**
 * Compose the currently implemented runtime boundaries.
 *
 * G1 owns canonical Domain persistence. G2+ services will be added here as
 * they are implemented, keeping construction in one place and preventing
 * alternate mutation paths from appearing by convenience.
 */
export function composeDomainManagerRuntime(
  options: DomainManagerRuntimeOptions = {}
): DomainManagerRuntime {
  const domainStore = options.domainStore ?? new FoundryDomainDocumentStore();

  return Object.freeze({
    domains: new DomainRepository(domainStore),
    authority: options.authority ?? new FoundryPrimaryAuthorityAdapter()
  });
}
