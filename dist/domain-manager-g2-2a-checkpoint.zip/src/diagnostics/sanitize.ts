const SENSITIVE_KEY = /(secret|token|password|api[-_]?key|credential|authorization)/i;

export function sanitizeDiagnosticsValue(value: unknown, ancestors = new WeakSet<object>()): unknown {
  if (Array.isArray(value)) {
    if (ancestors.has(value)) return "[Circular]";
    ancestors.add(value);
    const result = value.map((item) => sanitizeDiagnosticsValue(item, ancestors));
    ancestors.delete(value);
    return result;
  }
  if (typeof value !== "object" || value === null) return value;
  if (ancestors.has(value)) return "[Circular]";
  ancestors.add(value);

  const sanitized: Record<string, unknown> = {};
  for (const [key, child] of Object.entries(value)) {
    sanitized[key] = SENSITIVE_KEY.test(key)
      ? "[REDACTED]"
      : sanitizeDiagnosticsValue(child, ancestors);
  }
  ancestors.delete(value);
  return sanitized;
}
