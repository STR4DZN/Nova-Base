import { existsSync, readFileSync } from "node:fs";

const manifest = JSON.parse(readFileSync("module.json", "utf8"));
const requiredFiles = ["module.json", "dist/main.js", "dist/main.js.map"];

for (const file of requiredFiles) {
  if (!existsSync(file)) throw new Error(`Missing package file: ${file}`);
}

if (manifest.id !== "domain-manager") throw new Error("Invalid module id");
if (manifest.version !== "0.0.2") throw new Error("Invalid module version");
if (!manifest.scripts?.includes("dist/main.js")) {
  throw new Error("Manifest does not reference dist/main.js");
}
if (manifest.socket !== true) {
  throw new Error("Manifest must specify socket: true for Foundry v13 module socket routing");
}

const socketlibDep = manifest.relationships?.requires?.find((r) => r.id === "socketlib");
if (!socketlibDep) throw new Error("Manifest must declare socketlib in relationships.requires");
if (socketlibDep.compatibility?.minimum !== "1.1.3") {
  throw new Error(`Socketlib minimum compatibility must be 1.1.3 for Foundry v13, got ${socketlibDep.compatibility?.minimum}`);
}
if (socketlibDep.compatibility?.verified !== "1.1.4") {
  throw new Error(`Socketlib verified compatibility must be 1.1.4, got ${socketlibDep.compatibility?.verified}`);
}

console.info("Package validation passed");
